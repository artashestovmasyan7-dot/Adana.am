function openDonate() {
  document.getElementById('donate-popup').style.display = 'flex';
}

function closeDonate() {
  document.getElementById('donate-popup').style.display = 'none';
}

// Multilanguage placeholder
const languages = {
  hy: { home: "Գլխավոր", results: "Արդյունքներ", team: "Թիմ", sponsors: "Հովանավորներ", donate: "Նվիրատվություն" },
  en: { home: "Home", results: "Results", team: "Team", sponsors: "Sponsors", donate: "Donate" },
  ru: { home: "Главная", results: "Результаты", team: "Команда", sponsors: "Спонсоры", donate: "Пожертвовать" },
  fr: { home: "Accueil", results: "Résultats", team: "Équipe", sponsors: "Sponsors", donate: "Don" }
};

function switchLang(lang) {
  document.querySelector("nav ul li:nth-child(1) a").innerText = languages[lang].home;
  document.querySelector("nav ul li:nth-child(2) a").innerText = languages[lang].results;
  document.querySelector("nav ul li:nth-child(3) a").innerText = languages[lang].team;
  document.querySelector("nav ul li:nth-child(4) a").innerText = languages[lang].sponsors;
  document.querySelector("nav ul li:nth-child(5) a").innerText = languages[lang].donate;
}